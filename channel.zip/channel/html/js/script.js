$(document).ready(function(){
    /*
    $('.seachIcon').on('click', function(){
        $(this).parent().animate({'width': '250px'}, 100, function(){
            $('.searchField').show();
        });
    });
    */
    $('.hamburger').on('click', function(){
        $('.sidenav').animate({'width': '300px'}, 100);
    });
    $('.closebtn').on('click', function(){
        $('.sidenav').animate({'width': '0px'}, 100);
    });

    $('.post_slider').slick({
        slidesToShow: 4,
        slidesToScroll: 4,
        arrows: true,
        //prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fal fa-angle-left'></i></i></button>",
        //nextArrow:"<button type='button' class='slick-next pull-right'><i class='fal fa-angle-right'></i></i></button>",
        responsive: [
            {
              breakpoint: 990,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true
              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
    });
});